var searchData=
[
  ['newtonian',['newtonian',['../perturbations_8h.html#a393651984401ac059c225aed80e4862ca6f069c11c49f62f29dcbdcf0f19188ac',1,'perturbations.h']]]
];
