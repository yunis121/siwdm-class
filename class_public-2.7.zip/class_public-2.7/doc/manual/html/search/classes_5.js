var searchData=
[
  ['recombination',['recombination',['../thermodynamics_8h.html#structrecombination',1,'']]],
  ['reionization',['reionization',['../thermodynamics_8h.html#structreionization',1,'']]]
];
