var searchData=
[
  ['spatial_5fcurvature',['spatial_curvature',['../background_8h.html#a084e4b1d0e8008b93518986b89cd77ff',1,'background.h']]]
];
