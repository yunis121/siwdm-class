var searchData=
[
  ['where_20to_20find_20information_20and_20documentation_20on_20class_3f',['Where to find information and documentation on CLASS?',['../md_chap2.html',1,'']]]
];
