var searchData=
[
  ['phi_5fpivot_5fmethods',['phi_pivot_methods',['../primordial_8h.html#ad4961aeb87c56f59f886b346f898793a',1,'primordial.h']]],
  ['pk_5fdef',['pk_def',['../common_8h.html#aab161982846c9e414cccea37822f4b0c',1,'common.h']]],
  ['possible_5fgauges',['possible_gauges',['../perturbations_8h.html#a393651984401ac059c225aed80e4862c',1,'perturbations.h']]],
  ['potential_5fshape',['potential_shape',['../primordial_8h.html#abc9f57be3e8c9ae0afd2edabc57f71b5',1,'primordial.h']]],
  ['primordial_5fspectrum_5ftype',['primordial_spectrum_type',['../primordial_8h.html#a920d6a2fa14d663cb6d9a3fae5a4b27d',1,'primordial.h']]]
];
